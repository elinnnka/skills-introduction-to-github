## Missing functionality
Found this repository, read trough the documentation and missing some functionality for your needs? Open [a issue](https://github.com/MichielVanwelsenaere/HomeAutomation.CoDeSys3/issues/new), describe your needs, and we'll have a look! 
